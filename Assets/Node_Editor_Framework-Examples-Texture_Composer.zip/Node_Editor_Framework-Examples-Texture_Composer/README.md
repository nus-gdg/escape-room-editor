## Texture Composer Example

#### An example for the Node Editor Framework

<br>
<p align="center">
  <img alt="Texture Composer Example" src="http://i.imgur.com/HcXhhGf.png" width="80%"/>
</p>
 <br>

A very simple setup of a few texture nodes built upon the default calculation canvas. Start here to get a basic idea on how to create simple extensions for the framework with custom functionality.

Simply drop the Texture_Composer folder into a project with the current NodeEditorFramework/Develop installed and open the example canvas located at Texture_Composer/Resources/Saves/Texture Mix Canvas.asset
