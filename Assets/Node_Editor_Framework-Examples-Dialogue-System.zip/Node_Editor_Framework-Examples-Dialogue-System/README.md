Drag and Drop the Folder into your UnityPrject along with the NodeCanvas Files
The Example will then be workable
Opening up the "Dialog1" asset in Resources/Saves, will give you an example of the Dialog Canvas

To test, start up the BaseScene in _Scene folder. After Play 
"L" - Load the dailog

In project hierarchy you have "TestObject", with exposed field
Dialog ID [Id 1,2,3 are in the exmaple] and 
Value is used by the Multi path node : changing value here does not affect internally

To change Value press "A" in playmode to increment its value and save changes to DialogBlackboard that is used by the system for Conditional Path choosing

To test Various Dialog Types, Just change Dialog ID here and Press "L" to load and see the effect

Contact me in case of any queries @ChicK00o

P.S : This project serves only as an example to build on